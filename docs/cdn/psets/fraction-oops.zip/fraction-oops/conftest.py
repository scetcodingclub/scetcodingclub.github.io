import pytest

def pytest_addoption(parser):
    parser.addoption("--level", action="store", default="1", help="max level to run")

def pytest_configure(config):
    config.addinivalue_line("markers", "level(n): mark test as requiring level n")

def pytest_collection_modifyitems(config, items):
    max_level = int(config.getoption("--level"))
    skip_marker = pytest.mark.skip(reason=f"Level above {max_level}")
    for item in items:
        for marker in item.iter_markers(name="level"):
            if int(marker.args[0]) > max_level:
                item.add_marker(skip_marker)
