# 📘 Fraction Class — Problem Set

## 👋 Introduction

In this problem, you will implement a **Fraction** (rational number) class in Python.
Fractions are numbers like `1/2`, `-3/4`, or `7/1`. They can be added, multiplied, compared, and reduced to their simplest form.

This project is designed to practice **Object-Oriented Programming (OOP)** in Python. You will implement special methods (`__add__`, `__mul__`, etc.), learn about encapsulation, and gradually build up a complete class that behaves like Python’s own `fractions.Fraction`.

Just like in CS50, the distribution code has been provided for you. It contains skeleton methods with clear TODOs and comments. Your job is to **fill in the methods** level by level.

**NOTE: Carefully read the entire Problem Set before starting** 
**Also Carefully read the existing code and try to understand it**
You don't have to add any new functions to the Fraction class.
Although feel free to test it out by using the class.

---

## 🎯 Goal

* Implement the missing parts of the `Fraction` class.
* Learn how operator overloading works in Python (`+`, `*`, `==`, etc.).
* Practice incremental problem solving by completing levels one at a time.
* Use **unit testing** with `pytest` to verify correctness at each level.

---

## 🧩 Levels

This project is split into **levels**. Each level builds on the previous one.

* **Level 0:**
  Implement `get_gcd()` using recursion.
  (You need this to simplify fractions!)

* **Level 1:**
  Basic representations and arithmetic:
  `__repr__`, `__str__`, `__float__`, `__int__`, `normalize`, `__mul__`, `__eq__`.

* **Level 2:**
  Add and subtract fractions:
  `__add__`, `__sub__`, `__truediv__`, `__abs__`, `__neg__`.

* **Level 3:**
  In-place operations and normalization:
  `normalize_ip`, `__iadd__`, `__isub__`, `__imul__`, `__itruediv__`.

* **Level 4:**
  Encapsulation with read-only properties:
  `numerator`, `denominator`.

* **Level 5:**
  Comparisons:
  `__lt__`, `__le__`, `__gt__`, `__ge__`.

* **Level 6:**
  Reverse operations with integers:
  `__radd__`, `__rsub__`, `__rmul__`, `__rtruediv__`.
  Remember you can make use of the exixting code by converting the `int` to `Fraction` first

* **Level 7:**
  Advanced features:
  `__hash__`, `__copy__`, `__deepcopy__`.

* **Level 8 (Extra Credit 🚀):**
  This level is **not mandatory**.
  Here you combine Fractions with **integers** in all possible ways (`Fraction + 5`, `5 - Fraction`, etc.) and handle them cleanly.
  Before this you implemented (`Fraction + Fraction`, `Fraction += Fraction`, `int + Fraction`), now you'll implement (`Fraction + int`, `Fraction += int`), for all four operations (`+*/-`)
  Attempt this if you’re feeling confident!
  If you do decide to do this then modify the following functions:
  `__add__`, `__mul__`, `__sub__`, `__truediv__`
  `__iadd__`, `__imul__`, `__isub__`, `__itruediv__`
  and check if `other` is a `Fraction` or `int` using the `isinstance` python built-in function
  Remember you can make use of the exixting code by converting the `int` to `Fraction` first

---

## ✅ How to Test

We’ve provided **unit tests** using [pytest](https://docs.pytest.org/).

### 1. Install pytest (only once):

```bash
pip install pytest
```

### 2. Run tests for a specific level:

```bash
pytest --level=0
pytest --level=1
pytest --level=2
...
pytest --level=7
```

If you’re feeling confident, you can also try:

```bash
pytest --level=8
```

### 3. Run all tests:

```bash
pytest
```

---

## Download Starter Code:

[Download fraction-oops.zip](https://scetcodingclub.github.io/cdn/psets/fraction-oops.zip)

* After Downloading
* Unzip the file
* Open the folder in `Visual Studio Code`.
* Start implementing the methods inside `fraction.py`.

---

## 💡 Tips

* Always implement and test one level before moving to the next.
* If some levels are too hard, that’s okay! You can stop at any point and still have a working class.
* Carefully read the **docstrings** and **TODOs** in the distribution code — they are there to guide you.
* Remember: Think like a **library author**. Other programmers will use your Fraction class, so it must behave consistently and predictably.
* NOTE: Carefully read the entire Problem Set before starting
* Also Carefully read the existing code and try to understand it

---

## 💡 Type Hinting

In the distribution code, **type hints** are used to show what kinds of values a function takes as input and what it returns.

**General form:**

```python
def func_name(argument: type) -> return type
```

**Example from this problem set:**

```python
def gcd(a: int | float, b: int | float) -> int | float

```

This means:

* `a` can be an `int` or a `float`
* `b` can be an `int` or a `float`
* The function will return either an `int` or a `float`

⚠️ **Note:** Type hints are just hints — Python will still run even if they’re wrong.
But they’re very useful for clarity, testing, and avoiding bugs.


---

## ❓ Need Help

Stuck on something or want to share your progress? Join our community on Discord:
[💬 Join our Discord](https://discord.gg/hTEyejkxUH)

---

## 🔚 Closing

This problem will help you practice OOP in Python step by step, just like CS50 builds problems from “Hello, world” to full projects.

Even if you don’t complete all levels, you’ll learn a lot about **operator overloading, encapsulation, and testing** along the way.

Good luck, and happy coding! 🚀
