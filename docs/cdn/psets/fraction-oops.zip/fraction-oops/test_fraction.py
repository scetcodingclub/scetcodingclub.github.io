import pytest
import copy
import random
from fractions import Fraction as PyFraction # python's implementation
from main import Fraction, get_gcd


# -----------------------
# Level 0: Greatest Common Divisor
# -----------------------
@pytest.mark.level(0)  # utility function, even before Level 1
def test_gcd_basic_cases():
    assert get_gcd(0, 5) == 5
    assert get_gcd(5, 0) == 5
    assert get_gcd(0, 0) == 0
    assert get_gcd(7, 7) == 7
    assert get_gcd(1, 1) == 1

@pytest.mark.level(0)
def test_gcd_positive_numbers():
    assert get_gcd(10, 5) == 5
    assert get_gcd(25, 10) == 5
    assert get_gcd(81, 27) == 27
    assert get_gcd(100, 85) == 5

@pytest.mark.level(0)
def test_gcd_negative_numbers():
    # gcd should always return positive
    assert get_gcd(-10, 5) == 5
    assert get_gcd(10, -5) == 5
    assert get_gcd(-10, -5) == 5
    assert get_gcd(-25, 10) == 5

@pytest.mark.level(0)
def test_gcd_with_primes():
    assert get_gcd(13, 17) == 1
    assert get_gcd(19, 29) == 1
    assert get_gcd(2, 97) == 1

@pytest.mark.level(0)
def test_gcd_large_numbers():
    assert get_gcd(123456, 7890) == 6
    assert get_gcd(10**12, 10**6) == 10**6
    assert get_gcd(10**12 + 39, 10**6 + 17) == 1  # coprime


# -----------------------
# Level 1: Core
# -----------------------
@pytest.mark.level(1)
def test_level1_init_and_repr_str():
    assert repr(Fraction()) == "Fraction(0, 1)"
    assert str(Fraction()) == "0"
    assert str(Fraction(5)) == "5"
    assert str(Fraction(3, 4)) == "3/4"

@pytest.mark.level(1)
def test_level1_type_casts_and_normalize():
    f = Fraction(6, 8).normalize()
    assert f.n == 3 and f.d == 4
    assert float(Fraction(1, 2)) == 0.5
    assert int(Fraction(7, 3)) == 2
    assert int(Fraction(-7, 3)) == -2

@pytest.mark.level(1)
def test_level1_negative_denominator_normalization():
    f = Fraction(1, -2).normalize()
    assert f.n == -1 and f.d == 2

@pytest.mark.level(1)
def test_level1_mul_eq():
    f1 = Fraction(3, 2)
    f2 = Fraction(1, 3)
    assert f1 == f1
    assert f1 * f2 == Fraction(1, 2)

# -----------------------
# Level 2: Arithmetic
# -----------------------
@pytest.mark.level(2)
def test_level2_add_sub_mul_div():
    f1 = Fraction(1, 2)
    f2 = Fraction(1, 3)
    assert f1 + f2 == Fraction(5, 6)
    assert f1 - f2 == Fraction(1, 6)
    assert f1 * f2 == Fraction(1, 6)
    assert f1 / f2 == Fraction(3, 2)

@pytest.mark.level(2)
def test_level2_abs_neg():
    f = Fraction(-3, 4)
    assert abs(f) == Fraction(3, 4)
    assert abs(Fraction(3, 4)) == Fraction(3, 4)
    assert -f == Fraction(3, 4).normalize()

@pytest.mark.level(2)
def test_level2_divide_by_zero_fraction():
    with pytest.raises(ZeroDivisionError):
        Fraction(1, 2) / Fraction(0, 1)


# -----------------------
# Level 3: In-place ops
# -----------------------
@pytest.mark.level(3)
def test_level3_inplace_ops_and_identity():
    f = Fraction(1, 2)
    id_before = id(f)

    f += Fraction(1, 2)
    assert f == Fraction(1, 1)
    assert id(f) == id_before  # in-place keeps same object

    f *= Fraction(3, 2)
    assert f == Fraction(3, 2)

    f -= Fraction(1, 2)
    assert f == Fraction(1, 1)

    f /= Fraction(5, 4)
    assert f == Fraction(4, 5)

@pytest.mark.level(3)
def test_level3_divide_by_zero_fraction():
    f = Fraction(1, 2)
    with pytest.raises(ZeroDivisionError):
        f /= Fraction(0, 1)


# -----------------------
# Level 4: Encapsulation
# -----------------------
@pytest.mark.level(4)
def test_level4_properties_are_readonly():
    f = Fraction(7, 8)
    assert f.numerator == 7
    assert f.denominator == 8
    with pytest.raises(AttributeError):
        f.numerator = 10
    with pytest.raises(AttributeError):
        f.denominator = 0
    f = Fraction(10, 20)
    assert f.numerator == 1 and f.denominator == 2


# -----------------------
# Level 5: Comparisons
# -----------------------
@pytest.mark.level(5)
def test_level5_comparisons():
    f1 = Fraction(1, 2)
    f2 = Fraction(2, 4)
    f3 = Fraction(3, 4)

    assert f1 == f2
    assert f1 != f3
    assert f1 < f3
    assert f3 > f1
    assert f1 <= f2
    assert f3 >= f1

@pytest.mark.level(5)
def test_level5_comparison_with_zero_and_negatives():
    f = Fraction(-1, 2)
    assert f < Fraction()
    assert Fraction(0, 5) == Fraction(0, 1)


# -----------------------
# Level 6: Mixed type ops
# -----------------------
@pytest.mark.level(6)
def test_level6_mixed_type_operations():
    f = Fraction(1, 2)
    assert 1 + f == Fraction(3, 2)
    assert 1 - f == Fraction(1, 2)
    assert 2 * f == Fraction(1, 1)
    assert 2 / f == Fraction(4, 1)

@pytest.mark.level(6)
def test_level6_right_div_zero():
    with pytest.raises(ZeroDivisionError):
        12 / Fraction(0, 1)


# -----------------------
# Level 7: Integration
# -----------------------
@pytest.mark.level(7)
def test_level7_hashable_in_dict_and_set():
    f1 = Fraction(2, 4).normalize()
    f2 = Fraction(1, 2)
    d = {f1: "half"}
    assert d[f2] == "half"
    s = {f1, f2}
    assert len(s) == 1

@pytest.mark.level(7)
def test_level7_copy_and_deepcopy():
    f1 = Fraction(3, 4)
    f2 = copy.copy(f1)
    f3 = copy.deepcopy(f1)
    assert f1 == f2 == f3
    assert f1 is not f2
    assert f1 is not f3


# -----------------------
# Fuzz / Stress Testing
# -----------------------
@pytest.mark.level(7)
@pytest.mark.parametrize("_", range(5))  # run multiple independent fuzz batches
def test_fuzz_against_python_fraction(_):
    """
    Stress test our Fraction class against Python's fractions.Fraction.
    Randomized big + small integers, all implemented methods tested.
    """

    for _ in range(2000):  # adjust if too slow
        a, b = random.randint(-10**6, 10**6), random.randint(1, 10**6)
        c, d = random.randint(-10**6, 10**6), random.randint(1, 10**6)

        f1 = Fraction(a, b)
        f2 = Fraction(c, d)
        p1 = PyFraction(a, b)
        p2 = PyFraction(c, d)

        # --- Normalization ---
        f_tmp = Fraction(a*10, b*10)
        f_tmp.normalize_ip()
        assert f_tmp == Fraction(p1.numerator, p1.denominator)

        # --- String/float/int representations ---
        print(int(f1), int(p1), f1, p1, int(f1) == int(p1))
        assert int(f1) == int(p1)
        assert float(f1) == float(p1)
        # repr/str consistency
        if p1.denominator == 1:
            assert str(f1) == str(p1.numerator)
        else:
            assert str(f1) == f"{p1.numerator}/{p1.denominator}"

        # --- Arithmetic ---
        assert f1 + f2 == Fraction((p1+p2).numerator, (p1+p2).denominator)
        assert f1 - f2 == Fraction((p1-p2).numerator, (p1-p2).denominator)
        assert f1 * f2 == Fraction((p1*p2).numerator, (p1*p2).denominator)
        if c != 0:
            assert f1 / f2 == Fraction((p1/p2).numerator, (p1/p2).denominator)

        # --- In-place arithmetic ---
        tmp = Fraction(a, b); tmp += f2
        assert tmp == Fraction((p1+p2).numerator, (p1+p2).denominator)
        tmp = Fraction(a, b); tmp -= f2
        assert tmp == Fraction((p1-p2).numerator, (p1-p2).denominator)
        tmp = Fraction(a, b); tmp *= f2
        assert tmp == Fraction((p1*p2).numerator, (p1*p2).denominator)
        if c != 0:
            tmp = Fraction(a, b); tmp /= f2
            assert tmp == Fraction((p1/p2).numerator, (p1/p2).denominator)

        # --- Unary operations ---
        assert abs(f1) == Fraction(abs(p1.numerator), abs(p1.denominator)).normalize()
        assert -f1 == Fraction((-p1).numerator, (-p1).denominator)

        # --- Comparisons ---
        assert (f1 == f2) == (p1 == p2)
        assert (f1 < f2) == (p1 < p2)
        assert (f1 <= f2) == (p1 <= p2)
        assert (f1 > f2) == (p1 > p2)
        assert (f1 >= f2) == (p1 >= p2)

        # --- Properties ---
        assert f1.numerator == p1.numerator
        assert f1.denominator == p1.denominator

        # --- Hashing ---
        dct = {f1: "exists"}
        assert dct[Fraction(p1.numerator, p1.denominator)] == "exists"

        # --- Copying ---
        shallow = copy.copy(f1)
        deep = copy.deepcopy(f1)
        assert shallow == f1 and deep == f1
        assert shallow is not f1 and deep is not f1

@pytest.mark.level(7)
def test_level7_edge_cases():
    assert Fraction(0, 1) == Fraction()
    assert Fraction(-10, -20).normalize() == Fraction(1, 2)
    assert Fraction(123456789, 1) == Fraction(123456789)
    assert Fraction(1, -1) == Fraction(-1, 1)


# ----------------------------------------
# Level 8: Right Operations with int
# ----------------------------------------

@pytest.mark.level(8)
def test_level8_mixed_type_operations():
    f = Fraction(1, 2)
    assert f + 1 == Fraction(3, 2)
    assert 1 + f == Fraction(3, 2)
    assert f - 1 == Fraction(-1, 2)
    assert 1 - f == Fraction(1, 2)
    assert f * 2 == Fraction(1, 1)
    assert 2 * f == Fraction(1, 1)
    assert f / 2 == Fraction(1, 4)
    assert 2 / f == Fraction(4, 1)

@pytest.mark.level(8)
def test_level8_mixed_div_zero():
    f = Fraction(1, 2)
    with pytest.raises(ZeroDivisionError):
        f / 0

@pytest.mark.level(8)
def test_level8_inplace_with_ints():
    f = Fraction(1, 2)
    f += 1
    assert f == Fraction(3, 2)
    f *= 2
    assert f == Fraction(3, 1)
    f -= 1
    assert f == Fraction(2, 1)
    f /= 2
    assert f == Fraction(1, 1)

@pytest.mark.level(8)
def test_level8_inplace_div_zero():
    f = Fraction(1, 2)
    with pytest.raises(ZeroDivisionError):
        f /= Fraction(0, 1)

@pytest.mark.level(8)
def test_level8_chain_operations():
    f = Fraction(1, 2)
    result = f + 1 - Fraction(1, 3) * 2 / Fraction(5, 7)
    assert isinstance(result, Fraction)

    f = Fraction(1, 3)
    result = ((f + 2) * 3 - Fraction(4, 5)) / (f + 1)
    assert isinstance(result, Fraction)

# -----------------------
# Fuzz / Stress Testing
# -----------------------
@pytest.mark.level(8)
@pytest.mark.parametrize("_", range(5))  # run multiple independent fuzz batches
def test_level8_fuzz_mixed_int_ops(_):
    """
    Stress test Fraction with mixed int operations (+, -, *, /),
    verifying against Python's fractions.Fraction as ground truth.
    """

    for _ in range(2000):  # adjust for runtime
        a, b = random.randint(-10**6, 10**6), random.randint(1, 10**6)
        k = random.randint(-10**6, 10**6)  # random integer

        f1 = Fraction(a, b)
        p1 = PyFraction(a, b)

        # --- Addition ---
        assert f1 + k == Fraction((p1 + k).numerator, (p1 + k).denominator)
        assert k + f1 == Fraction((k + p1).numerator, (k + p1).denominator)

        # --- Subtraction ---
        assert f1 - k == Fraction((p1 - k).numerator, (p1 - k).denominator)
        assert k - f1 == Fraction((k - p1).numerator, (k - p1).denominator)

        # --- Multiplication ---
        assert f1 * k == Fraction((p1 * k).numerator, (p1 * k).denominator)
        assert k * f1 == Fraction((k * p1).numerator, (k * p1).denominator)

        # --- Division (guard zero) ---
        if k != 0:
            assert f1 / k == Fraction((p1 / k).numerator, (p1 / k).denominator)
            assert k / f1 == Fraction((k / p1).numerator, (k / p1).denominator)

        # --- In-place ops ---
        tmp = Fraction(a, b); tmp += k
        assert tmp == Fraction((p1 + k).numerator, (p1 + k).denominator)
        tmp = Fraction(a, b); tmp -= k
        assert tmp == Fraction((p1 - k).numerator, (p1 - k).denominator)
        tmp = Fraction(a, b); tmp *= k
        assert tmp == Fraction((p1 * k).numerator, (p1 * k).denominator)
        if k != 0:
            tmp = Fraction(a, b); tmp /= k
            assert tmp == Fraction((p1 / k).numerator, (p1 / k).denominator)
