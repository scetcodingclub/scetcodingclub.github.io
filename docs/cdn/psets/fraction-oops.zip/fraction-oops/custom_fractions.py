from typing import Self # Type hinting for self

# Level 0

def get_gcd(a: int, b: int) -> int:
    """Compute the greatest common divisor (GCD) of two integers using Euclid's algorithm."""
    # TODO
    # use recursion to compute the GCD of a & b


class Fraction:
    """
    A simple Fraction (Rational Number) class for representing and operating on fractions.
    """

    def __init__(self, *args) -> Self:
        """
        Create a Fraction object.

        Examples:
            Fraction()       -> 0/1
            Fraction(5)      -> 5/1
            Fraction(3, 4)   -> 3/4
        """
        if len(args) == 0:
            self.n, self.d = 0, 1
        elif len(args) == 1:
            self.n, self.d = args[0], 1
        elif len(args) == 2:
            self.n, self.d = args
        else:
            raise TypeError("Fraction() takes at most 2 arguments")

        if self.d == 0:
            raise ZeroDivisionError("Denominator cannot be zero")

        # Normalize signs and reduce fraction
        if self.d < 0:
            self.n, self.d = -self.n, -self.d
        self.normalize_ip()

    # Level 1

    def __repr__(self) -> str:
        """Return a developer-friendly string representation."""
        # TODO
        # return a string like: Fraction(3, 4)
        # with the numerator amd denominator

    def __str__(self) -> str:
        """Return a user-friendly string representation."""
        # TODO
        # return a string like: 3/4
        # with the numerator amd denominator

    def __float__(self) -> float:
        """Convert fraction to float."""
        # TODO

    def __int__(self) -> int:
        """Convert fraction to integer."""
        # TODO
    
    def __eq__(self, other: Self) -> bool:
        """Check equality between two fractions."""
        # TODO
        # return a bool (True/False)
    
    def normalize(self) -> Self:
        """Return a new normalized Fraction without modifying the current one."""
        # TODO
        # you need to use the gcd function

        # return a **new** Fraction with the new numerator and denominator
        # Do NOT modify the current object.
        # Use 'self.__class__' instead of literally 'Fraction' to create the **new** object

        # Example:
        #     f = Fraction(6, 8)
        #     g = f.normalize()
        #     # f is still 6/8
        #     # g is 3/4

        # This is useful when you want a simplified copy of the fraction,
        # while keeping the original unchanged.
    
    def __mul__(self, other: Self) -> Self:
        """Return the product of two fractions."""
        # TODO
        # return a new Fraction with the new numerator and denominator
        # Use 'self.__class__' instead of literally 'Fraction'
    
    # Level 2

    def __add__(self, other: Self) -> Self:
        """Return the sum of two fractions."""
        # TODO
        # return a new Fraction with the new numerator and denominator
        # Use 'self.__class__' instead of literally 'Fraction'
    
    def __sub__(self, other: Self) -> Self:
        """Return the difference between two fractions."""
        # TODO
        # return a new Fraction with the new numerator and denominator
        # Use 'self.__class__' instead of literally 'Fraction'
    
    def __truediv__(self, other: Self) -> Self:
        """Return the division of two fractions."""
        # TODO
        # raise ZeroDivisionError if other is zero
        # use the keyword 'raise'
        # remember you are programing a tool (Fraction class) for another programmer
        # think like a library author

        # return a new Fraction with the new numerator and denominator
        # Use 'self.__class__' instead of literally 'Fraction'
    
    def __abs__(self) -> Self:
        """Return the absolute value of the fraction."""
        # TODO
        # return a new Fraction with the new numerator and denominator
        # Use 'self.__class__' instead of literally 'Fraction'

    def __neg__(self) -> Self:
        """Return the negation of the fraction."""
        # TODO
        # return a new Fraction with the new numerator and denominator
        # Use 'self.__class__' instead of literally 'Fraction'
    
    # Level 3

    def normalize_ip(self):
        """Reduce the fraction to its simplest form, modifying it in place."""
        # TODO
        # Normalize in-place, modifying self.n and self.d
        # Reduce the Fraction to lowest terms, **modifying this object**.

        # Example:
        #     f = Fraction(6, 8)
        #     f.normalize_ip()
        #     # f is now 3/4 (same object, changed state)

        # In-place normalization is more memory-efficient and
        # is used inside the constructor and in-place operators
        # like +=, -=, etc.

    def __iadd__(self, other: Self) -> Self:
        """Add another fraction to this one in place."""
        # TODO
        # modify self, don't create a new one
        # return self at the end (python norm)
    
    def __isub__(self, other: Self) -> Self:
        """Subtract another fraction from this one in place."""
        # TODO
        # modify self, don't create a new one
        # return self at the end (python norm)

    def __imul__(self, other: Self) -> Self:
        """Multiply in place with another fraction."""
        # TODO
        # modify self, don't create a new one
        # return self at the end (python norm)

    def __itruediv__(self, other: Self) -> Self:
        """Divide this fraction by another fraction in place."""
        # TODO
        # raise ZeroDivisionError if other is zero
        # use the keyword 'raise'
        
        # modify self, don't create a new one
        # return self at the end (python norm)
    
    # Level 4

    @property
    def numerator(self) -> int:
        """Read-only access to the numerator of the fraction."""
        # TODO

    @property
    def denominator(self) -> int:
        """Read-only access to the denominator of the fraction."""
        # TODO
    
    # Level 5

    def __lt__(self, other: Self) -> bool:
        """Check if this fraction is less than another."""
        # TODO

    def __le__(self, other: Self) -> bool:
        """Check if this fraction is less than or equal to another."""
        # TODO

    def __gt__(self, other: Self) -> bool:
        """Check if this fraction is greater than another."""
        # TODO

    def __ge__(self, other: Self) -> bool:
        """Check if this fraction is greater than or equal to another."""
        # TODO
    
    # Level 6

    def __radd__(self, other: int) -> Self:
        """Support int + Fraction."""
        # TODO
        # add int to fraction
        # hint: convert int to fraction
        # Eg: self.__class__(int, 1)
        # denominator must be one

    def __rmul__(self, other: int) -> Self:
        """Support int * Fraction."""
        # TODO
        # multiply int to fraction
        # hint: convert int to fraction
        # Eg: self.__class__(int, 1)

    def __rsub__(self, other: int) -> Self:
        """Support int - Fraction."""
        # TODO
        # subtract int to fraction
        # hint: convert int to fraction
        # Eg: self.__class__(int, 1)

    def __rtruediv__(self, other: int) -> Self:
        """Support int / Fraction."""
        # TODO
        # divide int to fraction
        # hint: convert int to fraction
        # Eg: self.__class__(int, 1)
    
    # Level 7

    def __hash__(self) -> int:
        """Make Fraction usable as dict/set key."""
        # TODO
        # return a hash py passing the numerator and denominator in the 
        # built-in hash function

    def __copy__(self) -> Self:
        """Shallow copy support (copy.copy)."""
        # TODO
        # return a copy of self with the same numerator and denominator
        # Hint: look at the copy module documentation

    def __deepcopy__(self, memo) -> Self:
        """Deep copy support (copy.deepcopy)."""
        # TODO
        # return a copy of self with the same numerator and denominator
        # Hint: look at the copy module documentation

